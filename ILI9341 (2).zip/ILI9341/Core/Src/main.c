/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * @file           : main.c
 * @brief          : Main program body
 ******************************************************************************
 * @attention
 *
 * Copyright (c) 2024 STMicroelectronics.
 * All rights reserved.
 *
 * This software is licensed under terms that can be found in the LICENSE file
 * in the root directory of this software component.
 * If no LICENSE file comes with this software, it is provided AS-IS.
 *
 ******************************************************************************
 */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "ili9341.h"
#include "Bitmaps.h"
#include "personalizacion.h"
#include "mapas.h"
#include "game.h"
#include <stdlib.h>
#include <time.h>
#include <string.h>  // Incluir para usar memse
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
SPI_HandleTypeDef hspi1;

UART_HandleTypeDef huart5;

/* USER CODE BEGIN PV */
extern uint8_t fondo[];

//#define FLAG_INVULNERABLE (1 << 2)

unsigned char flags = 0;

uint8_t uart_buffer[UART_BUFFER_SIZE];  // Buffer para almacenar los datos recibidos
uint8_t uart_buffer1[UART_BUFFER_SIZE];
uint8_t uart_buffer2[UART_BUFFER_SIZE];
uint8_t uart_buffer3[UART_BUFFER_SIZE];
uint8_t uart_buffer4[UART_BUFFER_SIZE];
uint8_t uart_bufferP1[UART_BUFFER_SIZE];
uint8_t uart_bufferP2[UART_BUFFER_SIZE];

uint8_t uart_index = 0;  // Índice para el buffer
uint8_t temp[2];
uint8_t uart_recibir1 = 0;
uint8_t uart_recibir2 = 0;
uint8_t uart_recibir3 = 0;
uint8_t uart_recibir4 = 0;
uint8_t uart_recibirP1 = 0;
uint8_t uart_recibirP2 = 0;

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_SPI1_Init(void);
static void MX_UART5_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_SPI1_Init();
  MX_UART5_Init();
  /* USER CODE BEGIN 2 */

	LCD_Init();

	LCD_Clear(0x00);
	FillRect(0, 0, 319, 239, 0x0000);
	//FillRect(50, 60, 20, 20, 0xF800);
	//FillRect(70, 60, 20, 20, 0x07E0);
	//FillRect(90, 60, 20, 20, 0x001F);

	//LCD_Bitmap(0, 0, 320, 240, fondo);
	//LCD_Bitmap(100, 70, 14, 17, TanqueVerde);
	//LCD_Bitmap(100, 90, 14, 17, TanqueAqua);
	//FillRect(0, 0, 319, 206, 0x1911);

	//LCD_Print("Hola Mundo", 20, 100, 1, 0x001F, 0xCAB9);

	LCD_Bitmap(109, 40, 102, 91, logo);

	for (int x = 0; x < 319; x++) {
			//LCD_Bitmap(x, 225, 16, 15, ladrillo);
			LCD_Sprite(x,225,16,15,ladrillo,5,0,0,0);
			x += 15;
		}

	LCD_Sprite(93,166,18,18,TRAtaque,16,10,0,0); //Rosado
	LCD_Sprite(208,166,18,18,TAAtaque,16,0,0,0); //Azul
	HAL_Delay(1000);
	LCD_Sprite(93,166,18,18,TRAtaque,16,11,0,0); //Rosado
	LCD_Sprite(108,174,100,2,barra,4,0,0,0);
	HAL_Delay(100);
	LCD_Sprite(93,166,18,18,TRAtaque,16,10,0,0); //Rosado
	HAL_Delay(900);

	for (int x = 1; x < 4; x++) {
		LCD_Sprite(108,174,100,2,barra,4,x,0,0);
		LCD_Sprite(93,166,18,18,TRAtaque,16,10,0,0); //Rosado
		HAL_Delay(1000);
	}

	LCD_EraseSprite(93,166,133,18,0x0000);
	//HAL_UART_Receive_IT(&huart2, temp, 1);
	//HAL_UART_Receive_IT(&huart3, temp, 1);
	HAL_UART_Receive_IT(&huart5, temp, 1);

	while (!(flags & FLAG_pressA)){
		// Comprobar si el primer byte recibido es "A"
		if ((strncmp((char*)uart_bufferP1, "A1", UART_BUFFER_SIZE) == 0) | (strncmp((char*)uart_bufferP2, "A2", UART_BUFFER_SIZE) == 0)) {
			// Si el primer byte es "A", limpiar el buffer
			memset(uart_bufferP1, 0, UART_BUFFER_SIZE);  // Limpiar el buffer
			memset(uart_bufferP2, 0, UART_BUFFER_SIZE);
			flags |= FLAG_pressA;
		}
		LCD_Bitmap(10, 155, 300, 40, pressA);
		HAL_Delay(1000);
		LCD_EraseSprite(10,155,300,40,0x0000);
		HAL_Delay(1000);
	}

	HAL_UART_Transmit(&huart5, "1", 1, 100);

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
	while (1) {
		//***************************************************************************************************
		//selección de personajes
		//***************************************************************************************************
		flags |= FLAG_personalizacion;
		LCD_EraseSprite(0,0,320,225,0x0000);
		reiniciar();
		cicloPersonalizacion();
		LCD_EraseSprite(0,0,320,225,0x0000);
	  	srand(HAL_GetTick());
		seleccionar_mapa();
		inicializarTanques();
	    flags |= FLAG_partida;
		while (flags & FLAG_partida){
			renderizar_mapa();
			reiniciarTanques();
			iniciarPartida();
			ronda();
			final_partida();
		}
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
	}
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 80;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 2;
  RCC_OscInitStruct.PLL.PLLR = 2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief SPI1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI1_Init(void)
{

  /* USER CODE BEGIN SPI1_Init 0 */

  /* USER CODE END SPI1_Init 0 */

  /* USER CODE BEGIN SPI1_Init 1 */

  /* USER CODE END SPI1_Init 1 */
  /* SPI1 parameter configuration*/
  hspi1.Instance = SPI1;
  hspi1.Init.Mode = SPI_MODE_MASTER;
  hspi1.Init.Direction = SPI_DIRECTION_2LINES;
  hspi1.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi1.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi1.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi1.Init.NSS = SPI_NSS_SOFT;
  hspi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_2;
  hspi1.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi1.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi1.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi1.Init.CRCPolynomial = 10;
  if (HAL_SPI_Init(&hspi1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI1_Init 2 */

  /* USER CODE END SPI1_Init 2 */

}

/**
  * @brief UART5 Initialization Function
  * @param None
  * @retval None
  */
static void MX_UART5_Init(void)
{

  /* USER CODE BEGIN UART5_Init 0 */

  /* USER CODE END UART5_Init 0 */

  /* USER CODE BEGIN UART5_Init 1 */

  /* USER CODE END UART5_Init 1 */
  huart5.Instance = UART5;
  huart5.Init.BaudRate = 115200;
  huart5.Init.WordLength = UART_WORDLENGTH_8B;
  huart5.Init.StopBits = UART_STOPBITS_1;
  huart5.Init.Parity = UART_PARITY_NONE;
  huart5.Init.Mode = UART_MODE_TX_RX;
  huart5.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart5.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart5) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN UART5_Init 2 */

  /* USER CODE END UART5_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */
  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, LCD_RST_Pin|LCD_D1_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, LCD_RD_Pin|LCD_WR_Pin|LCD_RS_Pin|LCD_D7_Pin
                          |LCD_D0_Pin|LCD_D2_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, LCD_CS_Pin|LCD_D6_Pin|LCD_D3_Pin|LCD_D5_Pin
                          |LCD_D4_Pin|SD_SS_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : LCD_RST_Pin LCD_D1_Pin */
  GPIO_InitStruct.Pin = LCD_RST_Pin|LCD_D1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : LCD_RD_Pin LCD_WR_Pin LCD_RS_Pin LCD_D7_Pin
                           LCD_D0_Pin LCD_D2_Pin */
  GPIO_InitStruct.Pin = LCD_RD_Pin|LCD_WR_Pin|LCD_RS_Pin|LCD_D7_Pin
                          |LCD_D0_Pin|LCD_D2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : LCD_CS_Pin LCD_D6_Pin LCD_D3_Pin LCD_D5_Pin
                           LCD_D4_Pin SD_SS_Pin */
  GPIO_InitStruct.Pin = LCD_CS_Pin|LCD_D6_Pin|LCD_D3_Pin|LCD_D5_Pin
                          |LCD_D4_Pin|SD_SS_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /* USER CODE BEGIN MX_GPIO_Init_2 */
  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart){
	// Si hemos recibido 4 caracteres, reiniciamos el índice
	memcpy(uart_buffer + uart_index, temp, 1);
	if (++uart_index >= UART_BUFFER_SIZE) {
		uart_index = 0;

        switch (uart_buffer[0]) {
            case '1':
                memcpy(uart_buffer1, uart_buffer, UART_BUFFER_SIZE);
                uart_recibir1 = 1;
                break;
            case '2':
                memcpy(uart_buffer2, uart_buffer, UART_BUFFER_SIZE);
                uart_recibir2 = 1;
                break;
            case '3':
                memcpy(uart_buffer3, uart_buffer, UART_BUFFER_SIZE);
                uart_recibir3 = 1;
                break;
            case '4':
                memcpy(uart_buffer4, uart_buffer, UART_BUFFER_SIZE);
                uart_recibir4 = 1;
                break;
            default:
                // Si no es 1–4, ignoramos o podemos manejarlo como error
                break;
        }

        switch (uart_buffer[1]) {
			case '1':
				memcpy(uart_bufferP1, uart_buffer, UART_BUFFER_SIZE);
				uart_recibirP1 = 1;
				break;
			case '2':
				memcpy(uart_bufferP2, uart_buffer, UART_BUFFER_SIZE);
				uart_recibirP2 = 1;
				break;
			default:
				// Comando inválido o no manejado
				break;
		}
	}

	//HAL_UART_Receive_IT(&huart2, temp, 1);
	//HAL_UART_Receive_IT(&huart3, temp, 1);
	HAL_UART_Receive_IT(&huart5, temp, 1);
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
	/* User can add his own implementation to report the HAL error return state */
	__disable_irq();
	while (1) {
	}
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
