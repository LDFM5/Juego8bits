/*
 * game.c
 *
 *  Created on: Apr 8, 2025
 *      Author: luisd
 */

#include "game.h"

#define DIR_NONE 0
#define DIR_UP   1
#define DIR_DOWN 2
#define DIR_LEFT 3
#define DIR_RIGHT 4

#define BALA_TAM 2
#define BALAS_DELAY 20 // en milisegundos
#define MAX_BALAS 20

#define NUM_TIPOS_POWERUP 5


Bala balas_jugador1[MAX_BALAS];
Bala balas_jugador2[MAX_BALAS];

uint16_t disparo_delay_j1 = 0;
uint16_t disparo_delay_j2 = 0;

extern unsigned char flags;

const char* nombres_p[7] = {
		"Forest Viper", "Steel Tide", "Arctic Phantom", "Crimson Fury", "Blaze Core", "Rose Warden", "Void Stalker"
};

const unsigned char* tanques[8] = {
		TVAtaque, TAAtaque, TQAtaque, TRJAtaque, TNAtaque, TRAtaque, TMAtaque, TGAtaque
};

extern uint8_t contador1;
extern uint8_t contador2;

// Variables globales
Tanque jugador1;
Tanque jugador2;

PowerUp powerup;

extern uint8_t uart_buffer1[UART_BUFFER_SIZE];
extern uint8_t uart_buffer2[UART_BUFFER_SIZE];
extern uint8_t uart_buffer3[UART_BUFFER_SIZE];
extern uint8_t uart_buffer4[UART_BUFFER_SIZE];
extern uint8_t uart_bufferP1[UART_BUFFER_SIZE];
extern uint8_t uart_bufferP2[UART_BUFFER_SIZE];

extern int indice;

extern uint8_t uart_recibir1;
extern uint8_t uart_recibir2;
extern uint8_t uart_recibir3;
extern uint8_t uart_recibir4;
extern uint8_t uart_recibirP1;
extern uint8_t uart_recibirP2;

void inicializarTanques(void) {
    // Reset de vidas y rondas ganadas

    jugador1.rondas_ganadas = 0;
    jugador2.rondas_ganadas = 0;

    jugador1.disparo_delay = 0;
	jugador2.disparo_delay = 0;
	jugador1.jugador_id = 1; // 1 o 2
	jugador2.jugador_id = 2;

	jugador1.nombre = nombres_p[contador1]; // 1 o 2
	jugador2.nombre = nombres_p[contador2];

	flags |= FLAG_ronda;

}

int powerup_timer = 0;
int duracion_powerup1 = 0;
int duracion_powerup2 = 0;

int rafa1 = 0;
int rafa2 = 0;

int cont1 = 5;
int cont2 = 5;

int c1 = 0;
int c2 = 0;

int rafaga1 = 0;
int rafaga2 = 0;

void reiniciarTanques(void){
	// Coordenadas según el mapa seleccionado

	powerup.activo = false;

    jugador1.vidas = 3;
    jugador2.vidas = 3;

    jugador1.poder = 0;
    jugador2.poder = 0;

    jugador1.velocidad = 20;
    jugador2.velocidad = 20;
    jugador1.aplicado = false;
    jugador2.aplicado = false;

    rafa1 = 0;
    rafa2 = 0;

    cont1 = 4;
    cont2 = 4;

    c1 = 0;
    c2 = 0;

    rafaga1 = 0;
    rafaga2 = 0;

    powerup_timer = 0;
    duracion_powerup1 = 0;
    duracion_powerup2 = 0;

    for (int i = 0; i < MAX_BALAS; i++) {
    	balas_jugador1[i].activa = false;
    	balas_jugador1[i].x = 0;
    	balas_jugador1[i].y = 0;
    	balas_jugador1[i].dx = 0;
    	balas_jugador1[i].dy = 0;
    	balas_jugador2[i].activa = false;
		balas_jugador2[i].x = 0;
		balas_jugador2[i].y = 0;
		balas_jugador2[i].dx = 0;
		balas_jugador2[i].dy = 0;
    }

	switch (indice) {
		case 0:
			jugador1.x = 23;
			jugador1.y = 158;
			jugador2.x = 280;
			jugador2.y = 21;
			jugador1.orientacion = 4;
			jugador2.orientacion = 14;
			jugador1.aim = DIR_DOWN;
			jugador2.aim = DIR_LEFT;
			break;
		case 1:
			jugador1.x = 23;
			jugador1.y = 201;
			jugador2.x = 280;
			jugador2.y = 21;
			jugador1.orientacion = 0;
			jugador2.orientacion = 4;
			jugador1.aim = DIR_UP;
			jugador2.aim = DIR_DOWN;
			break;
		case 2:
			jugador1.x = 23;
			jugador1.y = 201;
			jugador2.x = 280;
			jugador2.y = 21;
			jugador1.orientacion = 10;
			jugador2.orientacion = 14;
			jugador1.aim = DIR_RIGHT;
			jugador2.aim = DIR_LEFT;
			break;
	}

	LCD_Sprite(jugador1.x,jugador1.y,18,18,tanques[contador1],16,jugador1.orientacion,0,0);
	LCD_Sprite(jugador2.x,jugador2.y,18,18,tanques[contador2],16,jugador2.orientacion,0,0);

}

void iniciarPartida(void) {

	LCD_Print(nombres_p[contador1], 8, 0, 1, 0xFFFF, 0x0000);

	int nombre_len = 314 - strlen(nombres_p[contador2])*8;
	LCD_Print(nombres_p[contador2], nombre_len, 0, 1, 0xFFFF, 0x0000);

    // Cuenta regresiva de 3 a 1
    for (int i = 3; i > 0; i--) {
        char buffer[10];
        sprintf(buffer, "%d", i);
        LCD_Print(buffer, 156, 228, 1, 0xFFFF, 0x0000);  // Texto blanco, fondo negro

        uint32_t start = HAL_GetTick();
        while (HAL_GetTick() - start < 1000);  // Espera de 1 segundo
    }

	memset(uart_buffer1, 0, UART_BUFFER_SIZE);
	memset(uart_buffer2, 0, UART_BUFFER_SIZE);
	memset(uart_buffer3, 0, UART_BUFFER_SIZE);
	memset(uart_buffer4, 0, UART_BUFFER_SIZE);
	memset(uart_bufferP1, 0, UART_BUFFER_SIZE);
	memset(uart_bufferP2, 0, UART_BUFFER_SIZE);

    // Activar bandera
    flags |= FLAG_ronda;

    // Borrar el conteo
    LCD_EraseSprite(0, 228, 320, 12, 0x0000);

    // Mostrar vidas, victorias y nombre del jugador
    char info[25];

    // Jugador 1
    sprintf(info, "W: %d  Lives: %d", jugador1.rondas_ganadas, jugador1.vidas);
    LCD_Print(info, 8, 228, 1, 0xFFFF, 0x0000);

    // Jugador 2
    sprintf(info, "W: %d  Lives: %d", jugador2.rondas_ganadas, jugador2.vidas);
    LCD_Print(info, 314-strlen(info)*8, 228, 1, 0xFFFF, 0x0000);
}

void mover_tanque(Tanque* jugador, int nueva_x, int nueva_y,
                  int ancho, int alto, const unsigned char* sprite, int columnas) {

    // Actualizar posición
    jugador->x = nueva_x;
    jugador->y = nueva_y;

    // Por defecto, si dirección y aim son iguales, solo se usa la dirección
    if (!(jugador->direccion == jugador->aim)) {

        if (jugador->direccion == DIR_NONE){
        	if (jugador->orientacion >= 0 && jugador->orientacion <= 7) {
        		if (jugador->aim == DIR_DOWN) {
        			jugador->orientacion = 4;
        		} else if (jugador->aim == DIR_LEFT) {
                    jugador->orientacion = 6;
        		} else if (jugador->aim == DIR_RIGHT) {
                    jugador->orientacion = 2;
                } else if (jugador->aim == DIR_UP) {
                    jugador->orientacion = 0;
                }
        	} else {
        		if (jugador->aim == DIR_DOWN) {
        			jugador->orientacion = 12;
        		} else if (jugador->aim == DIR_LEFT) {
                    jugador->orientacion = 14;
        		} else if (jugador->aim == DIR_RIGHT) {
                    jugador->orientacion = 10;
                } else if (jugador->aim == DIR_UP) {
                    jugador->orientacion = 8;
                }
        	}
        } else if (jugador->direccion == DIR_UP && jugador->aim == DIR_DOWN) {
            jugador->orientacion = 4;
        } else if (jugador->direccion == DIR_UP && jugador->aim == DIR_LEFT) {
            jugador->orientacion = 6;
        } else if (jugador->direccion == DIR_UP && jugador->aim == DIR_RIGHT) {
            jugador->orientacion = 2;
        } else if (jugador->direccion == DIR_DOWN && jugador->aim == DIR_UP) {
            jugador->orientacion = 0;
        } else if (jugador->direccion == DIR_DOWN && jugador->aim == DIR_LEFT) {
            jugador->orientacion = 6;
        } else if (jugador->direccion == DIR_DOWN && jugador->aim == DIR_RIGHT) {
            jugador->orientacion = 2;
        } else if (jugador->direccion == DIR_LEFT && jugador->aim == DIR_UP) {
            jugador->orientacion = 8;
        } else if (jugador->direccion == DIR_LEFT && jugador->aim == DIR_DOWN) {
            jugador->orientacion = 12;
        } else if (jugador->direccion == DIR_LEFT && jugador->aim == DIR_RIGHT) {
            jugador->orientacion = 10;
        } else if (jugador->direccion == DIR_RIGHT && jugador->aim == DIR_UP) {
            jugador->orientacion = 8;
        } else if (jugador->direccion == DIR_RIGHT && jugador->aim == DIR_DOWN) {
            jugador->orientacion = 12;
        } else if (jugador->direccion == DIR_RIGHT && jugador->aim == DIR_LEFT) {
            jugador->orientacion = 14;
        }
    }

    if (jugador->disparar == DIR_UP){
    	jugador->orientacion++;

    	// Incrementa contador hasta cierto valor antes de hacer el cambio
		if (++jugador->disparo_delay >= 5) {  // Esto sería cada 200ms si llamas cada 20ms
			jugador->disparar = DIR_DOWN;
			jugador->disparo_delay = 0;
		}
    }

    if (!jugador->aplicado || jugador->tipo != 4){
        // Dibujar nuevo sprite
        LCD_Sprite(jugador->x, jugador->y, ancho, alto, (unsigned char*)sprite,
                   columnas, jugador->orientacion, 0, 0);
    } else {
    	LCD_EraseSprite(jugador->x, jugador->y, ancho, alto, 0x0000);
    }

	switch (jugador->direccion) {
		case DIR_UP:    LCD_EraseSprite(jugador->x, jugador->y + 18, ancho, 1, 0x0000); break;
		case DIR_DOWN:  LCD_EraseSprite(jugador->x, jugador->y - 1, ancho, 1, 0x0000); break;
		case DIR_LEFT:  LCD_EraseSprite(jugador->x + 18, jugador->y, 1, alto, 0x0000); break;
		case DIR_RIGHT: LCD_EraseSprite(jugador->x - 1, jugador->y, 1, alto, 0x0000); break;
		default: return; // No hay movimiento
	}



}

void mover_jugador(Tanque* jugador, uint8_t contador) {
    int nueva_x = jugador->x;
    int nueva_y = jugador->y;
    int anterior = jugador->orientacion;

    switch (jugador->direccion) {
        case DIR_UP:    nueva_y--; jugador->orientacion = 0; break;
        case DIR_DOWN:  nueva_y++; jugador->orientacion = 4; break;
        case DIR_LEFT:  nueva_x--; jugador->orientacion = 14; break;
        case DIR_RIGHT: nueva_x++; jugador->orientacion = 10; break;
        default: break; // No hay movimiento
    }

    if (verificar_colision(nueva_x, nueva_y, jugador)) {
		// Mover tanque
		nueva_x = jugador->x;
		nueva_y = jugador->y;
		jugador->direccion = DIR_NONE;
		jugador->orientacion = anterior;
	}

    if (!jugador->aplicado || jugador->tipo != 3) {
        // Mover y borrar sprite anterior
        mover_tanque(jugador, nueva_x, nueva_y, 18, 18, tanques[contador], 16);
    } else {
        // Mover y borrar sprite anterior
        mover_tanque(jugador, nueva_x, nueva_y, 18, 18, tanques[7], 16);
    }

}

uint32_t tiempo_anteriorP1 = 0;
uint32_t tiempo_anteriorP2 = 0;
uint32_t tiempo_anterior2 = 0;
uint32_t intervalo2 = 10;  // cada 10 ms

void ronda(void) {
    while (flags & FLAG_ronda) {

        if (uart_recibir1) {
            // Tomamos los primeros 2 o 3 caracteres como comando
            if (strncmp((char*)uart_buffer1, "1U", 2) == 0) {
                jugador1.direccion = DIR_UP;
            } else if (strncmp((char*)uart_buffer1, "1D", 2) == 0) {
                jugador1.direccion = DIR_DOWN;
            } else if (strncmp((char*)uart_buffer1, "1L", 2) == 0) {
                jugador1.direccion = DIR_LEFT;
            } else if (strncmp((char*)uart_buffer1, "1R", 2) == 0) {
                jugador1.direccion = DIR_RIGHT;
            } else if (strncmp((char*)uart_buffer1, "1S", 2) == 0) {
                jugador1.direccion = DIR_NONE;
            }
            uart_recibir1 = 0;
        }

        if (uart_recibir3) {
            if (strncmp((char*)uart_buffer3, "3U", 2) == 0) {
                jugador2.direccion = DIR_UP;
            } else if (strncmp((char*)uart_buffer3, "3D", 2) == 0) {
                jugador2.direccion = DIR_DOWN;
            } else if (strncmp((char*)uart_buffer3, "3L", 2) == 0) {
                jugador2.direccion = DIR_LEFT;
            } else if (strncmp((char*)uart_buffer3, "3R", 2) == 0) {
                jugador2.direccion = DIR_RIGHT;
            } else if (strncmp((char*)uart_buffer3, "3S", 2) == 0) {
                jugador2.direccion = DIR_NONE;
            }

            uart_recibir3 = 0;
            //memset(uart_buffer, 0, UART_BUFFER_SIZE);
        }

        if (uart_recibir2) {
            if (strncmp((char*)uart_buffer2, "2U", 2) == 0) {
                jugador1.aim = DIR_UP;
            } else if (strncmp((char*)uart_buffer2, "2D", 2) == 0) {
                jugador1.aim = DIR_DOWN;
            } else if (strncmp((char*)uart_buffer2, "2L", 2) == 0) {
                jugador1.aim = DIR_LEFT;
            } else if (strncmp((char*)uart_buffer2, "2R", 2) == 0) {
                jugador1.aim = DIR_RIGHT;
            }
            uart_recibir2 = 0;
        }

        if (uart_recibir4) {
            if (strncmp((char*)uart_buffer4, "4U", 2) == 0) {
                jugador2.aim = DIR_UP;
            } else if (strncmp((char*)uart_buffer4, "4D", 2) == 0) {
                jugador2.aim = DIR_DOWN;
            } else if (strncmp((char*)uart_buffer4, "4L", 2) == 0) {
                jugador2.aim = DIR_LEFT;
            } else if (strncmp((char*)uart_buffer4, "4R", 2) == 0) {
                jugador2.aim = DIR_RIGHT;
            }
            uart_recibir4 = 0;
        }

        if (uart_recibirP1) {
			if (strncmp((char*)uart_bufferP1, "A1", 2) == 0) {
				disparar(&jugador1, balas_jugador1, &disparo_delay_j1, false);
				if (jugador1.aplicado && jugador1.tipo == 2) {
					rafaga1 = 2;
				}
			} else if ((strncmp((char*)uart_bufferP1, "B1", 2) == 0) && jugador1.poder) {
				aplicar_powerup(&jugador1);
			}
			uart_recibirP1 = 0;
		}

        if (uart_recibirP2) {
			if (strncmp((char*)uart_bufferP2, "A2", 2) == 0) {
			    disparar(&jugador2, balas_jugador2, &disparo_delay_j2, false);
				if (jugador2.aplicado && jugador2.tipo == 2) {
					rafaga2 = 2;
				}
			} else if ((strncmp((char*)uart_bufferP2, "B2", 2) == 0) && jugador2.poder) {
				aplicar_powerup(&jugador2);
			}
			uart_recibirP2 = 0;
		}

        uint32_t tiempo_actual = HAL_GetTick();

	   if ((tiempo_actual - tiempo_anteriorP1) >= jugador1.velocidad) {
		   tiempo_anteriorP1 = tiempo_actual;

		   // Movimiento continuo
		   mover_jugador(&jugador1, contador1);

	   }

	   if ((tiempo_actual - tiempo_anteriorP2) >= jugador2.velocidad) {
	   		   tiempo_anteriorP2 = tiempo_actual;

		   // Movimiento continuo
		   mover_jugador(&jugador2, contador2);

	   }

	   if ((tiempo_actual - tiempo_anterior2) >= intervalo2) {
		   tiempo_anterior2 = tiempo_actual;

		   // Movimiento continuo
		  // mover_jugador(&jugador2, contador2);
		   actualizar_balas(balas_jugador1, &jugador2, &jugador1);
		   if (disparo_delay_j1 > 0) disparo_delay_j1--;
		   actualizar_balas(balas_jugador2, &jugador1,  &jugador2);
		   if (disparo_delay_j2 > 0) disparo_delay_j2--;

		   if (!powerup.activo){
			   if (++powerup_timer >= 1000) {
			       powerup_timer = 0;
			       generar_powerup();
			   }
		   }

		   if (jugador1.aplicado) {
			   if (++duracion_powerup1 >= 500) {
				   duracion_powerup1 = 0;
				   desaplicar_powerup(&jugador1);
				   cont1 = 4;
				   LCD_EraseSprite(160-16, 228, 8, 12, 0x0000);
				   c1 = 0;
			   }

			   if (++c1 >= 100) {
				   c1 = 0;
				   char buffer[10];
				   sprintf(buffer, "%d", cont1);
				   LCD_Print(buffer, 160-16, 228, 1, 0xFFFF, 0x0000);
				   cont1--;
			   }
		   }

		   if (jugador2.aplicado) {
			   if (++duracion_powerup2 >= 500) {
				   duracion_powerup2 = 0;
				   cont2 = 4;
				   desaplicar_powerup(&jugador2);
				   LCD_EraseSprite(160+16, 228, 8, 12, 0x0000);
				   c2 = 0;
			   }

			   if (++c2 >= 100) {
				   c2 = 0;
				   char buffer[10];
				   sprintf(buffer, "%d", cont2);
				   LCD_Print(buffer, 160+16, 228, 1, 0xFFFF, 0x0000);
				   cont2--;
			   }
		   }


		   if (rafaga1 > 0) {
			   if (++rafa1 >= 10) {
				   rafa1 = 0;
				   disparar(&jugador1, balas_jugador1, &disparo_delay_j1, true);
				   rafaga1--;
			   }
		   }

		   if (rafaga2 > 0) {
			   if (++rafa2 >= 10) {
				   rafa2 = 0;
				   disparar(&jugador2, balas_jugador2, &disparo_delay_j2, true);
				   rafaga2--;
			   }
		   }


	   }

	   if (powerup.activo){
		   LCD_Sprite(powerup.x, powerup.y, BLOCK_WIDTH, BLOCK_HEIGHT, powerups,
		   				6, powerup.tipo, 0, 0);
	   }

	   if ((jugador1.poder && jugador1.tipo == 0) || ( jugador2.tipo == 0 && jugador2.poder)){
		   if (jugador1.poder){
			   aplicar_powerup(&jugador1);
		   } else {
			   aplicar_powerup(&jugador2);
		   }
	   }

	   if (jugador1.vidas == 0) {
		   final_ronda(&jugador2);
	   } else if (jugador2.vidas == 0) {
		   final_ronda(&jugador1);
	   }

    }
}

void aplicar_powerup(Tanque* jugador) {

	HAL_UART_Transmit(&huart5, "3", 1, 100);

	switch (jugador->tipo) {
        case 0: // Vida extra
            jugador->vidas += 1;
			char info[25];
			sprintf(info, "W: %d  Lives: %d", jugador->rondas_ganadas, jugador->vidas);
			if (jugador->jugador_id == 1){
			   LCD_Print(info, 8, 228, 1, 0xFFFF, 0x0000);
			} else {
			   LCD_Print(info, 313-strlen(info)*8, 228, 1, 0xFFFF, 0x0000);
			}
            break;

        case 1: // Velocidad
            jugador->velocidad = 10;
        	jugador->aplicado = true;

        	if (jugador->jugador_id == 1){
        		LCD_Print("5", 160-16, 228, 1, 0xFFFF, 0x0000);
        	} else {
        		LCD_Print("5", 160+16, 228, 1, 0xFFFF, 0x0000);
        	}

            break;

        default:
        	jugador->aplicado = true;

        	if (jugador->jugador_id == 1){
        		LCD_Print("5", 160-16, 228, 1, 0xFFFF, 0x0000);
        	} else {
        		LCD_Print("5", 160+16, 228, 1, 0xFFFF, 0x0000);
        	}
        	break;
    }

    // Reinicia el poder después de aplicarlo (si es de un solo uso)
    jugador->poder = false;

}

void desaplicar_powerup(Tanque* jugador) {

	jugador->aplicado = false;

    if (jugador->tipo == 1) {
    	jugador->velocidad = 20;
    }

}


extern uint8_t mapa_actual[MAP_HEIGHT][MAP_WIDTH];

void generar_powerup() {
    // Generar solo con cierta probabilidad
    if (rand() % 100 <= 30 || powerup.activo) return;

    int intentos = 100;
    while (intentos--) {
        // Generar coordenadas aleatorias dentro del mapa
        int celda_x = rand() % MAP_WIDTH;
        int celda_y = rand() % MAP_HEIGHT;

        // Asegurarse de que la celda está vacía
        if (mapa_actual[celda_y][celda_x] != 0) continue;

        int px = celda_x * BLOCK_WIDTH;
        int py = celda_y * BLOCK_HEIGHT;

        // Verificar que no colisiona con jugador1
        if (px + BLOCK_WIDTH > jugador1.x && px < jugador1.x + TANK_SIZE &&
            py + BLOCK_HEIGHT > jugador1.y && py < jugador1.y + TANK_SIZE) continue;

        // Verificar que no colisiona con jugador2
        if (px + BLOCK_WIDTH > jugador2.x && px < jugador2.x + TANK_SIZE &&
            py + BLOCK_HEIGHT > jugador2.y && py < jugador2.y + TANK_SIZE) continue;

        // Posición válida
        powerup.x = px;
        powerup.y = py;
        powerup.tipo = rand() % NUM_TIPOS_POWERUP;
        powerup.activo = true;
		LCD_Sprite(powerup.x, powerup.y, BLOCK_WIDTH, BLOCK_HEIGHT, powerups,
				6, powerup.tipo, 0, 0);

        // Aquí podrías llamar a una función para dibujarlo
        // dibujar_powerup(powerup.x, powerup.y, powerup.tipo);
        break;
    }
}

void final_ronda(Tanque* jugador){

	HAL_UART_Transmit(&huart5, "4", 1, 100);

	jugador->rondas_ganadas += 1;
	// Apagar la bandera
	flags &= ~FLAG_ronda;

	LCD_EraseSprite(0, 0, 320, 240, 0x0000);

	if (jugador->rondas_ganadas != 3){

		char info[25];
		// Jugador 1
		sprintf(info, "%s won the round!", jugador->nombre);
		LCD_Print(info, 160-strlen(info)*4, 114, 1, 0xFFFF, 0x0000);

		HAL_Delay(3000);
	}


}

void final_partida(void){

	char info[25];

	if (jugador1.rondas_ganadas == 3) {
		sprintf(info, "%s won the match!", jugador1.nombre);
		LCD_Print(info, 160-strlen(info)*4, 114, 1, 0xFFFF, 0x0000);
		flags &= ~FLAG_partida;
		HAL_Delay(3000);
   } else if (jugador2.rondas_ganadas == 3) {
		sprintf(info, "%s won the match!", jugador2.nombre);
		LCD_Print(info, 160-strlen(info)*4, 114, 1, 0xFFFF, 0x0000);
		flags &= ~FLAG_partida;
		HAL_Delay(3000);
   }


}

bool verificar_colision(uint16_t x, uint16_t y, Tanque* jugador) {
    // Coordenadas de las 4 esquinas
    uint16_t puntos_x[2] = {x, x + TANK_SIZE - 1};
    uint16_t puntos_y[2] = {y, y + TANK_SIZE - 1};

    for (int i = 0; i < 2; i++) {
        for (int j = 0; j < 2; j++) {
            uint8_t celda_x = puntos_x[i] / BLOCK_WIDTH;
            uint8_t celda_y = puntos_y[j] / BLOCK_HEIGHT;

            if (mapa_actual[celda_y][celda_x] != 0) {
                return true;
            }
        }
    }

    // Colisión con el otro tanque
    Tanque* otro = (jugador == &jugador1) ? &jugador2 : &jugador1;

    if (x + TANK_SIZE > otro->x && x < otro->x + TANK_SIZE &&
        y + TANK_SIZE > otro->y && y < otro->y + TANK_SIZE) {
        return true;
    }

    // Verificar colisión con el power-up
    if (powerup.activo &&
        x + TANK_SIZE > powerup.x && x < powerup.x + BLOCK_WIDTH &&
        y + TANK_SIZE > powerup.y && y < powerup.y + BLOCK_HEIGHT) {

    	jugador->poder = true;
        jugador->tipo = powerup.tipo;    // Asignar poder al jugador
		LCD_EraseSprite(powerup.x, powerup.y, BLOCK_WIDTH, BLOCK_HEIGHT, 0x0000);
        powerup.activo = false;           // Desactivar el power-up
        // Aquí puedes borrar visualmente el power-up si quieres
        // LCD_EraseSprite(powerup.x, powerup.y, POWERUP_SIZE, POWERUP_SIZE, 0x0000);
    }

    return false;
}

void disparar(Tanque* jugador, Bala* balas, uint16_t* delay, bool rafaga) {

	/*if (!rafaga){
		if (*delay > 0) return; // aún no se puede disparar
	}*/
	HAL_UART_Transmit(&huart5, "2", 1, 100);

	jugador->disparar = DIR_UP;

    // Buscar bala inactiva
    for (int i = 0; i < MAX_BALAS; i++) {
        if (!balas[i].activa) {
            balas[i].x = jugador->x + TANK_SIZE / 2 - 1;
            balas[i].y = jugador->y + TANK_SIZE / 2 - 1;

            switch (jugador->aim) {
                case DIR_UP:    balas[i].dx = 0;  balas[i].dy = -1; break;
                case DIR_DOWN:  balas[i].dx = 0;  balas[i].dy = 1;  break;
                case DIR_LEFT:  balas[i].dx = -1; balas[i].dy = 0;  break;
                case DIR_RIGHT: balas[i].dx = 1;  balas[i].dy = 0;  break;
                default: return;
            }

            balas[i].activa = true;
            *delay = BALAS_DELAY;
            break;
        }
    }
}


void actualizar_balas(Bala* balas, Tanque* enemigo, Tanque* owner) {
    for (int i = 0; i < MAX_BALAS; i++) {
        if (!balas[i].activa) continue;

        bool fantasma = false;

        // Calcular siguiente posición
        int nueva_x = balas[i].x + balas[i].dx;
        int nueva_y = balas[i].y + balas[i].dy;

        for (int dy = 0; dy < BALA_TAM; dy++) {
            for (int dx = 0; dx < BALA_TAM; dx++) {
                int px = nueva_x + dx;
                int py = nueva_y + dy;

				int cx = px / BLOCK_WIDTH;
				int cy = py / BLOCK_HEIGHT;

				LCD_EraseSprite(balas[i].x, balas[i].y, BALA_TAM, BALA_TAM, 0x0000);

				// Verificar colisión con el mapa

				if (mapa_actual[cy][cx] != 0) {
					balas[i].activa = false;

					if (mapa_actual[cy][cx] != 1){
						if (mapa_actual[cy][cx] == 5){
							mapa_actual[cy][cx] = 0;
							LCD_EraseSprite(cx*BLOCK_WIDTH, cy*BLOCK_HEIGHT, BLOCK_WIDTH,
									BLOCK_HEIGHT, 0x0000);
						} else {
							mapa_actual[cy][cx] += 1;
							LCD_Sprite(cx*BLOCK_WIDTH, cy*BLOCK_HEIGHT, BLOCK_WIDTH, BLOCK_HEIGHT, ladrillo,
									5, mapa_actual[cy][cx]-1, 0, 0);
						}
					}
					return;
				}

            }
        }

        // Verificar colisión con el tanque enemigo
        if (balas[i].x + BALA_TAM > enemigo->x && balas[i].x < enemigo->x + TANK_SIZE &&
            balas[i].y + BALA_TAM > enemigo->y && balas[i].y < enemigo->y + TANK_SIZE) {
        	if (!enemigo->aplicado || enemigo->tipo != 3){
                enemigo->vidas--;
        	}
            balas[i].activa = false;

			char info[25];
			sprintf(info, "W: %d  Lives: %d", enemigo->rondas_ganadas, enemigo->vidas);
			if (enemigo->jugador_id == 1){
			   LCD_Print(info, 8, 228, 1, 0xFFFF, 0x0000);
			} else {
			   LCD_Print(info, 313-strlen(info)*8, 228, 1, 0xFFFF, 0x0000);
			}
			LCD_EraseSprite(balas[i].x, balas[i].y, BALA_TAM, BALA_TAM, 0x0000);
			return;
        }

        if (!fantasma) {
            LCD_EraseSprite(balas[i].x, balas[i].y, BALA_TAM, BALA_TAM, 0x0000);
        }

        // Si no hubo colisión, entonces sí mueve la bala
        balas[i].x = nueva_x;
        balas[i].y = nueva_y;

		LCD_EraseSprite(balas[i].x, balas[i].y, BALA_TAM, BALA_TAM, 0xFFFF);
    }
}
