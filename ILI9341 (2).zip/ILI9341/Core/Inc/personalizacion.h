/*
 * Misfunciones.h
 *
 *  Created on: Apr 5, 2025
 *      Author: luisd
 */

#ifndef INC_PERSONALIZACION_H_
#define INC_PERSONALIZACION_H_

#include "ili9341.h"
#include "Bitmaps.h"
#include "main.h"
#include <string.h>

void reiniciar(void);

// Prototipo de la función que implementa el ciclo de personalización
void cicloPersonalizacion(void);

#endif /* INC_PERSONALIZACION_H_ */
