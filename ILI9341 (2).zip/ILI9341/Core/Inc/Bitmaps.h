/*
 * Bitmaps.h
 *
 *  Created on: Apr 3, 2025
 *      Author: jaidy
 */

#ifndef INC_BITMAPS_H_
#define INC_BITMAPS_H_


extern const unsigned char logo[];

extern const unsigned char barra[];

extern const unsigned char pressA[];

extern const unsigned char ladrillo[];

extern const unsigned char powerups[];

extern const unsigned char TVAtaque[]; // verde

extern const unsigned char TAAtaque[]; // azul

extern const unsigned char TQAtaque[]; // aqua

extern const unsigned char TRJAtaque[]; // rojo

extern const unsigned char TNAtaque[]; // Naranja

extern const unsigned char TGAtaque[]; // gris

extern const unsigned char TRAtaque[]; // rosado

extern const unsigned char TMAtaque[]; // morado

extern const unsigned char TVEscalado[]; // verde

extern const unsigned char TAEscalado[]; // azul

extern const unsigned char TQEscalado[]; // aqua

extern const unsigned char TRJEscalado[]; // rojo

extern const unsigned char TNEscalado[]; // Naranja

extern const unsigned char TGAEscalado[]; // gris

extern const unsigned char TREscalado[]; // rosado

extern const unsigned char TMEscalado[]; // morado

extern const unsigned char flechas[];

extern const unsigned char players[];

extern const unsigned char Nverde[]; // verde

extern const unsigned char Nazul[]; // azul

extern const unsigned char Naqua[]; // aqua

extern const unsigned char Nrojo[]; // rojo

extern const unsigned char Nnaranja[]; // Naranja

extern const unsigned char Nrosado[]; // rosado

extern const unsigned char Nmorado[]; // morado


#endif /* INC_BITMAPS_H_ */
