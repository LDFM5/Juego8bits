/*
 * game.h
 *
 *  Created on: Apr 8, 2025
 *      Author: luisd
 */

#ifndef INC_GAME_H_
#define INC_GAME_H_

#include "ili9341.h"
#include "Bitmaps.h"
#include "main.h"
#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <stdlib.h> // para rand()

typedef struct {
    int x;
    int y;
    uint8_t vidas;
    uint8_t rondas_ganadas;
    uint8_t orientacion;
    int direccion;
    int aim;
    int disparar;
    bool poder;
    int tipo;
    bool aplicado;
    int disparo_delay;
    uint8_t jugador_id; // 1 o 2
    const char* nombre;
    uint32_t velocidad;
} Tanque;

typedef struct {
    int x;
    int y;
    int dx;
    int dy;
    bool activa;
} Bala;

typedef struct {
    int x, y;
    uint8_t tipo; // 0 = vida, 1 = velocidad, etc.
    bool activo;
} PowerUp;

void inicializarTanques(void);

void reiniciarTanques(void);

void iniciarPartida(void);

void mover_tanque(Tanque* jugador, int nueva_x, int nueva_y,
                  int ancho, int alto, const unsigned char* sprite, int columnas);

void mover_jugador(Tanque* jugador, uint8_t contador);

void ronda(void);

void aplicar_powerup(Tanque* jugador);

void desaplicar_powerup(Tanque* jugador);

void generar_powerup(void);

void final_ronda(Tanque* jugador);

void final_partida(void);

bool verificar_colision(uint16_t x, uint16_t y, Tanque* jugador);

void disparar(Tanque* jugador, Bala* balas, uint16_t* delay, bool rafaga);

void actualizar_balas(Bala* balas, Tanque* enemigo, Tanque* owner);

#endif /* INC_GAME_H_ */
