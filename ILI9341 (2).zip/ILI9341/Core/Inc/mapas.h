/*
 * mapas.h
 *
 *  Created on: Apr 6, 2025
 *      Author: luisd
 */

#ifndef INC_MAPAS_H_
#define INC_MAPAS_H_

#include "ili9341.h"
#include "Bitmaps.h"
#include "main.h"
#include <string.h>


void seleccionar_mapa(void);

void renderizar_mapa(void);

#endif /* INC_MAPAS_H_ */
