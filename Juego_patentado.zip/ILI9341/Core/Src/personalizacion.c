/*
 * Misfunciones.c
 *
 *  Created on: Apr 5, 2025
 *      Author: luisd
 */
// mi_funciones.c
#include <personalizacion.h>  // Incluir el encabezado con el prototipo de la función

extern unsigned char flags;

extern uint8_t uart_buffer1[UART_BUFFER_SIZE];
extern uint8_t uart_buffer3[UART_BUFFER_SIZE];
extern uint8_t uart_bufferP1[UART_BUFFER_SIZE];
extern uint8_t uart_bufferP2[UART_BUFFER_SIZE];

uint32_t tiempo_inicio;  // Guarda el tiempo actual
uint32_t tiempo_inicio2;  // Guarda el tiempo actual

extern uint8_t uart_recibir1;
extern uint8_t uart_recibir3;
extern uint8_t uart_recibirP1;
extern uint8_t uart_recibirP2;

uint8_t cambio = 0;

// Crear un arreglo de punteros a los bitmaps
const unsigned char* bitmap[7] = {
    TVEscalado, TAEscalado, TQEscalado, TRJEscalado, TNEscalado, TREscalado, TMEscalado
};

const unsigned char* nombres[7] = {
    Nverde, Nazul, Naqua, Nrojo, Nnaranja, Nrosado, Nmorado
};

uint8_t contador1 = 0;  // Contador para el primer bitmap
uint8_t contador2 = 1;  // Contador para el segundo bitmap

uint8_t ready1 = 0;
uint8_t ready2 = 0;

uint8_t conflicto = 0;

void reiniciar(void){
	memset(uart_buffer1, 0, UART_BUFFER_SIZE);
	memset(uart_buffer3, 0, UART_BUFFER_SIZE);
	memset(uart_bufferP1, 0, UART_BUFFER_SIZE);
	memset(uart_bufferP2, 0, UART_BUFFER_SIZE);
	ready1 = 0;
	ready2 = 0;
}

void cicloPersonalizacion(void) {

	// Mostrar los bitmaps correspondientes a cada contador
	LCD_Bitmap(60, 93, 40, 40, bitmap[contador1]);  // Mostrar primer bitmap
	LCD_Bitmap(220, 93, 40, 40, bitmap[contador2]); // Mostrar segundo bitmap

	LCD_Sprite(20,93,40,40,flechas,4,2,0,0);
	LCD_Sprite(100,93,40,40,flechas,4,3,0,0);

	LCD_Sprite(180,93,40,40,flechas,4,2,0,0);
	LCD_Sprite(260,93,40,40,flechas,4,3,0,0);

	LCD_Sprite(0,159,160,40,players,2,0,0,0);
	LCD_Sprite(160,159,160,40,players,2,1,0,0);

	LCD_Bitmap(0, 20, 160, 40, nombres[contador1]);  // Mostrar primer bitmap
	LCD_Bitmap(160, 20, 160, 40, nombres[contador2]); // Mostrar segundo bitmap

	tiempo_inicio = HAL_GetTick();  // Guarda el tiempo actual
	tiempo_inicio2 = HAL_GetTick();

    // Establecer el ciclo solo mientras la bandera FLAG_personalizacion esté activada
    while (flags & FLAG_personalizacion) {

    	if (ready1 && ready2){
    		flags &= ~FLAG_personalizacion;
    	}

    	if (uart_recibir1){
    		// Verificar el buffer UART para actualizar los contadores
			if ((strncmp((char*)uart_buffer1, "1L", UART_BUFFER_SIZE) == 0) && (!ready1)) {  // Si recibimos "1J1L"
				if (contador1 > 0) {
					contador1--;
				} else {
					contador1 = 6;  // Da la vuelta
				}
				LCD_Sprite(20,93,40,40,flechas,4,0,0,0);
				cambio = 1;
				conflicto = 0;
			} else if ((strncmp((char*)uart_buffer1, "1R", UART_BUFFER_SIZE) == 0) && (!ready1)) {  // Si recibimos "1J1R"
				if (contador1 < 6) {
					contador1++;
				} else {
					contador1 = 0;  // Da la vuelta
				}
				LCD_Sprite(100,93,40,40,flechas,4,1,0,0);
				cambio = 1;
				conflicto = 0;
			}

    		// Mostrar los bitmaps correspondientes a cada contador
			LCD_Bitmap(60, 93, 40, 40, bitmap[contador1]);  // Mostrar primer bitmap
			LCD_Bitmap(220, 93, 40, 40, bitmap[contador2]); // Mostrar segundo bitmap

			LCD_Bitmap(0, 20, 160, 40, nombres[contador1]);  // Mostrar primer bitmap
			LCD_Bitmap(160, 20, 160, 40, nombres[contador2]); // Mostrar segundo bitmap

			uart_recibir1 = 0;
    	}

    	if (uart_recibir3){
    		if ((strncmp((char*)uart_buffer3, "3L", UART_BUFFER_SIZE) == 0) && (!ready2)) {  // Si recibimos "2J1L"
				if (contador2 > 0) {
					contador2--;
				} else {
					contador2 = 6;  // Da la vuelta
				}
				LCD_Sprite(180,93,40,40,flechas,4,0,0,0);
				cambio = 1;
				conflicto = 0;
			} else if ((strncmp((char*)uart_buffer3, "3R", UART_BUFFER_SIZE) == 0) && (!ready2)) {  // Si recibimos "2J1R"
				if (contador2 < 6) {
					contador2++;
				} else {
					contador2 = 0;  // Da la vuelta
				}
				LCD_Sprite(260,93,40,40,flechas,4,1,0,0);
				cambio = 1;
				conflicto = 0;
			}

    		// Mostrar los bitmaps correspondientes a cada contador
			LCD_Bitmap(60, 93, 40, 40, bitmap[contador1]);  // Mostrar primer bitmap
			LCD_Bitmap(220, 93, 40, 40, bitmap[contador2]); // Mostrar segundo bitmap

			LCD_Bitmap(0, 20, 160, 40, nombres[contador1]);  // Mostrar primer bitmap
			LCD_Bitmap(160, 20, 160, 40, nombres[contador2]); // Mostrar segundo bitmap

			uart_recibir3 = 0;
    	}

    	if (uart_recibirP1){
    		if (strncmp((char*)uart_bufferP1, "A1", UART_BUFFER_SIZE) == 0){
				if ((contador1 == contador2) && (ready2)){
					LCD_EraseSprite(50,200,100,20,0x0000);
					LCD_Print("Already in use!", 20, 200, 1, 0xFFFF, 0x0000);
					conflicto = 1;
				} else {
					LCD_EraseSprite(50,200,100,20,0x0000);
					LCD_Print("Ready!", 57, 200, 1, 0xFFFF, 0x0000);
					ready1 = 1;
				}
			} else if (strncmp((char*)uart_bufferP1, "B1", UART_BUFFER_SIZE) == 0){
				ready1 = 0;
				conflicto = 0;
			}
			uart_recibirP1 = 0;
    	}

    	if (uart_recibirP2){
    		if (strncmp((char*)uart_bufferP2, "A2", UART_BUFFER_SIZE) == 0){
    			if ((contador1 == contador2) && (ready1)){
					LCD_EraseSprite(210,200,100,20,0x0000);
					LCD_Print("Already in use!", 180, 200, 1, 0xFFFF, 0x0000);
					conflicto = 1;
				} else {
	    			LCD_EraseSprite(210,200,100,20,0x0000);
					LCD_Print("Ready!", 217, 200, 1, 0xFFFF, 0x0000);
					ready2 = 1;
				}
    		} else if (strncmp((char*)uart_bufferP2, "B2", UART_BUFFER_SIZE) == 0){
				ready2 = 0;
				conflicto = 0;
			}
			//memset(uart_buffer, 0, sizeof(uart_buffer));

			uart_recibirP2 = 0;
    	}

    	if ((HAL_GetTick() - tiempo_inicio >= 500) && cambio) {  // 1000 ms = 1 segundo
    	    // Ha pasado 1 segundo, haz lo que quieras aquí
    		LCD_Sprite(20,93,40,40,flechas,4,2,0,0);
			LCD_Sprite(100,93,40,40,flechas,4,3,0,0);

			LCD_Sprite(180,93,40,40,flechas,4,2,0,0);
			LCD_Sprite(260,93,40,40,flechas,4,3,0,0);

    	    tiempo_inicio = HAL_GetTick();  // Reinicia el tiempo para la próxima espera
    	    cambio = 0;
    	}

    	if (!conflicto){
        	if (HAL_GetTick() - tiempo_inicio2 <= 1000){
        		if (!ready1){
        			LCD_EraseSprite(0,200,160,20,0x0000);
    			}

    			if (!ready2){
    				LCD_EraseSprite(160,200,160,20,0x0000);
    			}
        	} else if(HAL_GetTick() - tiempo_inicio2 <= 2000) {
        		if (!ready1){
        			LCD_Print("Press A", 50, 200, 1, 0xFFFF, 0x0000);
        		}

        		if (!ready2){
        			LCD_Print("Press A", 210, 200, 1, 0xFFFF, 0x0000);
        		}
        	} else {
        		tiempo_inicio2 = HAL_GetTick();
        	}
    	}

    }
}


