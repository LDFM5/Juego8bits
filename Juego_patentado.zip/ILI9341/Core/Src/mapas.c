/*
 * mapas.c
 *
 *  Created on: Apr 6, 2025
 *      Author: luisd
 */
#include "fatfs.h"
#include "mapas.h"
#include <stdlib.h> // para rand()
#include "fatfs_sd.h"
#include "string.h"
#include "stdio.h"

int indice;

//SPI_HandleTypeDef hspi1;
FATFS fs;
FATFS *pfs;
FIL fil;
FRESULT flres;
DWORD fre_clust;
uint32_t totalSpace, freeSpace;
UINT bytesRead;
char buffer[100];

uint8_t mapas[NUM_MAPS][MAP_HEIGHT][MAP_WIDTH];

/*
 const unsigned char mapas[NUM_MAPS][MAP_HEIGHT][MAP_WIDTH] = {
 // Mapa 1
 {
 {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
 {1,0,0,0,0,0,2,0,0,0,0,2,0,0,0,0,0,0,0,1},
 {1,0,0,0,0,0,2,0,0,0,0,0,0,0,0,0,0,0,0,1},
 {1,0,0,1,1,1,1,1,1,1,0,0,0,1,1,1,1,0,0,1},
 {1,0,0,0,0,0,0,0,0,1,1,2,2,1,0,0,0,0,0,1},
 {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
 {1,2,2,1,1,1,1,0,0,0,0,0,0,0,0,0,1,2,2,1},
 {1,0,0,0,0,0,1,0,0,1,1,1,1,1,1,1,1,0,0,1},
 {1,0,0,0,0,0,1,0,0,0,0,0,0,1,0,0,0,0,0,1},
 {1,1,1,1,0,0,1,0,0,0,0,0,0,1,0,0,0,0,0,1},
 {1,0,0,1,0,0,1,0,0,1,1,0,0,0,0,0,1,2,2,1},
 {1,0,0,1,0,0,1,0,0,2,0,0,0,0,0,0,1,0,0,1},
 {1,0,0,1,0,0,1,0,0,2,0,0,0,1,1,1,1,0,0,1},
 {1,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,1},
 {1,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,1},
 {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1}
 },
 // Mapa 2
 {
 {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
 {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,1},
 {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,1},
 {1,0,0,1,1,1,1,2,2,1,1,1,1,1,0,0,1,0,0,1},
 {1,0,0,0,0,0,2,0,0,1,1,0,0,1,0,0,2,0,0,1},
 {1,0,0,0,0,0,2,0,0,0,0,0,0,1,0,0,2,0,0,1},
 {1,1,1,1,0,0,1,0,0,0,0,0,0,1,1,1,1,0,0,1},
 {1,0,0,0,0,0,1,0,0,1,1,0,0,0,0,0,0,0,0,1},
 {1,0,0,0,0,0,1,0,0,1,1,0,0,0,0,0,0,0,0,1},
 {1,0,0,1,2,2,1,0,0,1,1,2,2,1,0,0,1,1,1,1},
 {1,0,0,1,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,1},
 {1,0,0,1,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,1},
 {1,0,0,1,1,1,1,2,2,1,1,0,0,1,2,2,1,0,0,1},
 {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
 {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
 {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1}
 },
 // Mapa 3
 {
 {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
 {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
 {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
 {1,0,0,1,1,0,0,0,0,1,1,0,0,1,1,1,1,2,2,1},
 {1,0,0,1,1,0,0,0,0,1,1,0,0,0,0,0,0,0,0,1},
 {1,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,1},
 {1,0,0,0,0,0,0,0,0,1,1,1,1,1,0,0,1,1,1,1},
 {1,0,0,1,2,2,1,0,0,2,2,0,0,0,0,0,0,0,0,1},
 {1,0,0,0,0,0,0,0,0,2,2,0,0,0,0,0,0,0,0,1},
 {1,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,0,0,1},
 {1,0,0,1,1,1,1,0,0,1,1,0,0,0,0,0,2,0,0,1},
 {1,0,0,1,0,0,0,0,0,2,0,0,0,0,0,0,2,0,0,1},
 {1,2,2,1,0,0,0,0,0,2,0,0,0,0,0,1,1,0,0,1},
 {1,0,0,0,0,0,2,0,0,0,0,0,1,0,0,0,0,0,0,1},
 {1,0,0,0,0,0,2,0,0,0,0,0,1,0,0,0,0,0,0,1},
 {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1}
 }
 };*/

unsigned char mapa_actual[MAP_HEIGHT][MAP_WIDTH];
unsigned char mapa_original[MAP_HEIGHT][MAP_WIDTH];

void seleccionar_mapa() {

	indice = rand() % NUM_MAPS; // Número aleatorio entre 0 y NUM_MAPS - 1

	char nombre_archivo[20];
	sprintf(nombre_archivo, "mapa%d.bin", indice + 1);

	flres = f_mount(&fs, "/", 0);

	flres = f_open(&fil, nombre_archivo, FA_READ);
	flres = f_read(&fil, mapas[indice], MAP_HEIGHT * MAP_WIDTH, &bytesRead);
	flres = f_close(&fil);

	flres = f_mount(NULL, "", 1);
	//indice = 1;
	// Copiar el mapa seleccionado al mapa_actual
	for (int y = 0; y < MAP_HEIGHT; y++) {
		for (int x = 0; x < MAP_WIDTH; x++) {
			mapa_original[y][x] = mapas[indice][y][x];
		}
	}
}

void renderizar_mapa() {

	for (int y = 0; y < MAP_HEIGHT; y++) {
		for (int x = 0; x < MAP_WIDTH; x++) {
			mapa_actual[y][x] = mapa_original[y][x];
		}
	}

	LCD_EraseSprite(0, 114, 320, 14, 0x0000);

	for (int y = 0; y < MAP_HEIGHT; y++) {
		for (int x = 0; x < MAP_WIDTH; x++) {
			unsigned char tipo = mapa_actual[y][x];

			if (tipo == 1 || tipo == 2) {
				// Dibujar sprite del bloque
				int px = x * 16;
				int py = y * 15;

				// tipo - 1 da 0 para fijo, 1 para rompible (asumiendo que están en ese orden)
				LCD_Sprite(px, py, 16, 15, ladrillo, 5, tipo - 1, 0, 0);
				//LCD_Bitmap(px, py, 16, 15, ladrillo);
			}
			// Si es 0 (vacío), no se dibuja nada
		}
	}

	// Borrar el conteo
	LCD_EraseSprite(0, 0, 320, 12, 0x0000);
	LCD_EraseSprite(0, 228, 320, 20, 0x0000);
}

